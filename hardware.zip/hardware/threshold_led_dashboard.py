"""Local browser dashboard for the ESP32 threshold LED demo.

Wi-Fi link: ESP32 SoftAP 192.168.4.1, TCP port 3333.
The app sends newline-delimited value,threshold pairs. Temperature is simulated;
no sensor or real Peltier is connected or controlled.
"""
from datetime import datetime
import math
import socket
import threading

from dash import Dash, dcc, html, Input, Output, State, ctx
import plotly.graph_objects as go

AMBIENT_C = 26.0
MAX_POINTS = 90
_lock = threading.Lock()
_tcp = None

C = {"bg": "#07111f", "panel": "#0d1b2d", "border": "#1b344d", "text": "#e7f0fb", "muted": "#91a6bd", "cyan": "#49d8e8", "green": "#53dfa5", "red": "#ff7185", "amber": "#ffc46b"}
INITIAL = {"running": False, "temp": 28.5, "threshold": 30.0, "active": False, "history": [], "cycle": 0}
app = Dash(__name__, title="Thermal Control | Threshold Demo")
server = app.server


def card(children, style=None):
    s = {"background": C["panel"], "border": f'1px solid {C["border"]}', "borderRadius": "18px", "padding": "20px", "boxShadow": "0 14px 40px rgba(0,0,0,.18)"}
    if style: s.update(style)
    return html.Div(children, style=s)


def metric(label, ident, suffix=""):
    return card([html.Div(label.upper(), style={"fontSize": "11px", "letterSpacing": "1.4px", "color": C["muted"], "fontWeight": 700}), html.Div([html.Span(id=ident), html.Span(suffix, style={"fontSize": "15px", "color": C["muted"], "marginLeft": "6px"})], style={"fontSize": "31px", "fontWeight": 700, "marginTop": "12px"})], {"minHeight": "105px"})

app.layout = html.Div([
    dcc.Store(id="sim-state", data=INITIAL),
    dcc.Store(id="hw-state", data={"connected": False, "ip": None}),
    dcc.Interval(id="clock", interval=1000, n_intervals=0),
    html.Div([
        html.Div([html.Div("THERMAL SYSTEMS  /  DEMO", style={"color": C["cyan"], "fontSize": "11px", "letterSpacing": "2px", "fontWeight": 700}), html.H1("Threshold Control", style={"fontSize": "34px", "margin": "9px 0 5px"}), html.Div("Temperature response and Peltier activation simulation", style={"color": C["muted"], "fontSize": "14px"})]),
        html.Div([html.Span("●  ", style={"color": C["green"]}), "LOCAL DASHBOARD · WI-FI HARDWARE LINK"], style={"padding": "11px 15px", "border": "1px solid #225742", "borderRadius": "999px", "background": "#0b2926", "color": "#9bf2cb", "fontSize": "11px", "fontWeight": 700, "letterSpacing": ".5px"})
    ], style={"display": "flex", "justifyContent": "space-between", "alignItems": "center", "gap": "20px", "flexWrap": "wrap", "marginBottom": "24px"}),

    html.Div([
        card([
            html.Div("SIMULATION INPUTS", style={"fontSize": "11px", "letterSpacing": "1.4px", "fontWeight": 700, "color": C["muted"], "marginBottom": "15px"}),
            html.Div([
                html.Div([html.Label("Starting temperature (°C)", style={"color": C["muted"], "fontSize": "12px"}), dcc.Input(id="start-temp", type="number", value=28.5, step="any", className="input")], style={"flex": "1", "minWidth": "160px"}),
                html.Div([html.Label("Activation threshold (°C)", style={"color": C["muted"], "fontSize": "12px"}), dcc.Input(id="threshold", type="number", value=30, step="any", className="input")], style={"flex": "1", "minWidth": "160px"})
            ], style={"display": "flex", "gap": "14px", "flexWrap": "wrap"}),
            html.Button("▶  APPLY & RUN", id="apply", n_clicks=0, className="apply"),
            html.Div("Temperature then changes once per second in the software model.", style={"color": C["muted"], "fontSize": "11px", "marginTop": "11px"})
        ], {"flex": "1.1", "minWidth": "320px"}),
        card([
            html.Div("SYSTEM STATE", style={"fontSize": "11px", "letterSpacing": "1.4px", "fontWeight": 700, "color": C["muted"]}),
            html.Div(id="state-pill", children="READY", style={"display": "inline-block", "marginTop": "17px", "padding": "10px 14px", "borderRadius": "999px", "fontWeight": 800, "fontSize": "12px", "letterSpacing": "1px", "background": "#182a3c", "color": C["muted"]}),
            html.Div(id="state-message", children="Apply values to start.", style={"fontSize": "14px", "fontWeight": 650, "marginTop": "14px", "minHeight": "40px"}),
            html.Div(id="led-state", children="Virtual indicators: waiting", style={"fontSize": "12px", "color": C["muted"], "marginTop": "8px"})
        ], {"flex": ".9", "minWidth": "270px"})
    ], style={"display": "flex", "gap": "15px", "flexWrap": "wrap", "marginBottom": "15px"}),

    card([
        html.Div("ESP32 LOCAL WI-FI LINK", style={"fontSize": "11px", "letterSpacing": "1.4px", "fontWeight": 700, "color": C["muted"], "marginBottom": "8px"}),
        html.Div("Connect the laptop’s Wi-Fi to ESP32-Threshold-LED first. Password: ThresholdLED123", style={"fontSize": "12px", "color": C["muted"], "marginBottom": "12px"}),
        html.Div([dcc.Input(id="esp32-ip", type="text", value="192.168.4.1", className="input", style={"maxWidth": "280px", "marginTop": 0}), html.Button("CONNECT ESP32", id="connect", n_clicks=0, className="secondary")], style={"display": "flex", "alignItems": "center", "gap": "10px", "flexWrap": "wrap"}),
        html.Div(id="hardware-status", children="Not connected — software simulation works without the ESP32.", style={"fontSize": "12px", "color": C["muted"], "marginTop": "10px"})
    ], {"marginBottom": "15px"}),

    html.Div([metric("Simulated temperature", "temp-value", "°C"), metric("Threshold", "threshold-value", "°C"), metric("Ambient model", "ambient-value", "°C"), metric("Cooling cycles", "cycle-value")], style={"display": "grid", "gridTemplateColumns": "repeat(auto-fit,minmax(175px,1fr))", "gap": "13px", "marginBottom": "15px"}),

    card([html.Div([html.Div([html.Div("TEMPERATURE RESPONSE", style={"fontSize": "11px", "letterSpacing": "1.4px", "fontWeight": 700, "color": C["muted"]}), html.Div("Live model history", style={"fontSize": "12px", "color": C["muted"], "marginTop": "5px"})]), html.Div([html.Span("— threshold", style={"color": C["red"], "fontSize": "11px", "marginRight": "14px"}), html.Span("— simulated temperature", style={"color": C["cyan"], "fontSize": "11px"})])], style={"display": "flex", "justifyContent": "space-between", "alignItems": "center", "gap": "10px", "flexWrap": "wrap"}), dcc.Graph(id="chart", config={"displayModeBar": False, "responsive": True}, style={"height": "350px"})], {"marginBottom": "15px"}),
    html.Div([html.Span("IMPORTANT  ", style={"fontWeight": 800, "color": C["amber"]}), "The temperature trace is simulated, not measured. The LEDs indicate the threshold state; no Peltier is physically switched. USB is still needed to power the ESP32 unless another power source is available."], style={"padding": "14px 17px", "borderRadius": "14px", "border": "1px solid #5a4828", "background": "#211b12", "color": "#d8c7a6", "fontSize": "12px", "lineHeight": "1.6"})
], style={"maxWidth": "1180px", "margin": "0 auto", "padding": "32px 23px", "color": C["text"]})

app.index_string = '''<!DOCTYPE html><html><head>{%metas%}<title>{%title%}</title>{%favicon%}{%css%}<style>
*{box-sizing:border-box}body{margin:0;background:#07111f;color:#e7f0fb;font-family:Inter,"Segoe UI",Arial,sans-serif}.input{display:block;width:100%;padding:12px;border-radius:10px;border:1px solid #29435d;background:#091625;color:#f4f8fc;font-size:15px;outline:none}.input:focus{border-color:#49d8e8;box-shadow:0 0 0 3px rgba(73,216,232,.12)}.apply{width:100%;border:0;border-radius:10px;padding:13px;margin-top:15px;background:linear-gradient(100deg,#28baca,#4b8cff);color:#06131f;font-weight:800;letter-spacing:.5px;cursor:pointer}.secondary{border:1px solid #29435d;border-radius:10px;padding:12px 14px;background:#102238;color:#dbe9f8;font-weight:750;font-size:11px;letter-spacing:.4px;cursor:pointer}.secondary:hover{border-color:#49d8e8;color:#49d8e8}.dash-graph{background:transparent!important}
</style></head><body>{%app_entry%}<footer>{%config%}{%scripts%}{%renderer%}</footer></body></html>'''


def make_figure(state):
    hist = state.get("history", [])
    fig = go.Figure()
    if hist:
        x, y = [p[0] for p in hist], [p[1] for p in hist]
        fig.add_trace(go.Scatter(x=x, y=[state["threshold"]] * len(x), mode="lines", line={"color": C["red"], "width": 2, "dash": "dash"}, hoverinfo="skip"))
        fig.add_trace(go.Scatter(x=x, y=y, mode="lines", line={"color": C["cyan"], "width": 3, "shape": "spline"}, fill="tozeroy", fillcolor="rgba(73,216,232,.08)", hovertemplate="%{y:.2f} °C<extra>Simulated</extra>"))
    else:
        fig.add_annotation(text="Apply values to start the temperature simulation", x=.5, y=.5, xref="paper", yref="paper", showarrow=False, font={"color": C["muted"], "size": 14})
    fig.update_layout(template="plotly_dark", paper_bgcolor=C["panel"], plot_bgcolor=C["panel"], margin={"l": 48, "r": 18, "t": 12, "b": 42}, showlegend=False, hovermode="x unified", xaxis={"title": "Simulation time", "gridcolor": "#1c3045"}, yaxis={"title": "Temperature (°C)", "gridcolor": "#1c3045", "zeroline": False}, font={"color": C["muted"], "family": "Segoe UI, Arial"})
    return fig


def send_value(value, threshold):
    global _tcp
    with _lock:
        if _tcp is None:
            return False
        try:
            _tcp.sendall(f"{value:.6g},{threshold:.6g}\n".encode("ascii"))
            _tcp.settimeout(0.03)
            try:
                _tcp.recv(512)  # drain Arduino's line response
            except socket.timeout:
                pass
            return True
        except OSError:
            try: _tcp.close()
            except OSError: pass
            _tcp = None
            return False


@app.callback(Output("hw-state", "data"), Output("connect", "children"), Input("connect", "n_clicks"), State("esp32-ip", "value"), State("hw-state", "data"), prevent_initial_call=True)
def toggle_connection(_clicks, ip, state):
    global _tcp
    state = state or {"connected": False, "ip": None}
    with _lock:
        if _tcp is not None:
            try: _tcp.close()
            except OSError: pass
            _tcp = None
            return {"connected": False, "ip": None}, "CONNECT ESP32"
        try:
            _tcp = socket.create_connection((str(ip).strip(), 3333), timeout=3)
            _tcp.settimeout(0.1)
            try: _tcp.recv(512)  # discard READY banner
            except socket.timeout: pass
            return {"connected": True, "ip": str(ip).strip()}, "DISCONNECT"
        except (OSError, ValueError):
            _tcp = None
            return {"connected": False, "ip": str(ip).strip()}, "CONNECT ESP32"


@app.callback(Output("sim-state", "data"), Input("apply", "n_clicks"), Input("clock", "n_intervals"), State("start-temp", "value"), State("threshold", "value"), State("sim-state", "data"), State("hw-state", "data"))
def update_sim(n_clicks, ticks, start, threshold, state, hw):
    state = dict(state or INITIAL)
    if ctx.triggered_id == "apply":
        try:
            temp, limit = float(start), float(threshold)
            if not math.isfinite(temp) or not math.isfinite(limit): return state
        except (TypeError, ValueError):
            return state
        active = temp >= limit
        if hw and hw.get("connected"): send_value(temp, limit)
        return {"running": True, "temp": temp, "threshold": limit, "active": active, "history": [[datetime.now().strftime("%H:%M:%S"), temp]], "cycle": 0}
    if ctx.triggered_id != "clock" or not state.get("running"):
        return state
    temp, limit = float(state["temp"]), float(state["threshold"])
    was_active = bool(state["active"])
    if temp >= limit:
        target = min(AMBIENT_C, limit - 1.0)
        temp += max(target - temp, -0.30) if temp > target else 0.0
    else:
        temp += max(min(AMBIENT_C - temp, 0.06), -0.06)
    temp = round(temp, 3)
    active = temp >= limit
    if hw and hw.get("connected"): send_value(temp, limit)
    hist = list(state.get("history", []))
    hist.append([datetime.now().strftime("%H:%M:%S"), temp])
    return {"running": True, "temp": temp, "threshold": limit, "active": active, "history": hist[-MAX_POINTS:], "cycle": int(state.get("cycle", 0)) + int(was_active and not active)}


@app.callback(Output("temp-value", "children"), Output("threshold-value", "children"), Output("ambient-value", "children"), Output("cycle-value", "children"), Output("state-pill", "children"), Output("state-pill", "style"), Output("state-message", "children"), Output("led-state", "children"), Output("chart", "figure"), Output("hardware-status", "children"), Input("sim-state", "data"), Input("hw-state", "data"))
def render(state, hw):
    state, hw = state or INITIAL, hw or {"connected": False}
    temp, limit = float(state.get("temp", INITIAL["temp"])), float(state.get("threshold", INITIAL["threshold"]))
    active = bool(state.get("active")) if state.get("running") else temp >= limit
    if active:
        label = "SIMULATED PELTIER ON"
        message = "Threshold reached — activation represented by the red LED."
        leds = "RED LED ON  ·  WHITE LED OFF"
        pill = {
            "display": "inline-block",
            "marginTop": "17px",
            "padding": "10px 14px",
            "borderRadius": "999px",
            "fontWeight": 800,
            "fontSize": "12px",
            "letterSpacing": "1px",
            "background": "#3b1e2a",
            "color": C["red"],
            }
    else:
        label = "PELTIER INACTIVE"
        message = "Below threshold — white LED indicates normal condition."
        leds = "WHITE LED ON  ·  RED LED OFF"
        pill = {
            "display": "inline-block",
            "marginTop": "17px",
            "padding": "10px 14px",
            "borderRadius": "999px",
            "fontWeight": 800,
            "fontSize": "12px",
            "letterSpacing": "1px",
            "background": "#12352e",
            "color": C["green"],
        }
    if not state.get("running"):
        label, message, leds = "READY", "Apply values to start the simulation.", "Virtual indicators: waiting"
    if hw.get("connected") and _tcp is not None:
        hw_text = f"Connected wirelessly to ESP32 at {hw.get('ip')}:3333. Dashboard sends updates once per second."
    elif hw.get("connected"):
        hw_text = "Wi-Fi link was lost. Check that the laptop is still connected to ESP32-Threshold-LED, then reconnect."
    else:
        hw_text = "Not connected — software simulation works without ESP32. USB power is still required."
    return f"{temp:.2f}", f"{limit:.2f}", f"{AMBIENT_C:.1f}", str(state.get("cycle", 0)), label, pill, message, leds, make_figure(state), hw_text


if __name__ == "__main__":
    print("Dashboard: http://127.0.0.1:8051")
    print("Stop with Ctrl+C. ESP32 Wi-Fi server is at 192.168.4.1:3333.")
    app.run(host="127.0.0.1", port=8051, debug=False)
