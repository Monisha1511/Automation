/*
  ESP32 Threshold LED Demonstration - Wi-Fi SoftAP + TCP

  Commands from the local Python dashboard use this newline-terminated format:
      value,threshold

  The ESP32 creates a Wi-Fi network and accepts TCP on 192.168.4.1:3333.

  Indicator behavior:
      value < threshold  -> WHITE LED indicates normal condition
      value >= threshold -> RED LED indicates threshold crossed

  This is a simulation. It does not measure real temperature or switch a
  Peltier module.
*/
#include <WiFi.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

const uint8_t RED_LED_PIN = 25;
const uint8_t WHITE_LED_PIN = 26;
const char *AP_SSID = "ESP32-Threshold-LED";
const char *AP_PASSWORD = "ThresholdLED123";
const uint16_t TCP_PORT = 3333;
const size_t LINE_BUFFER_SIZE = 96;

WiFiServer server(TCP_PORT);
WiFiClient activeClient;
char lineBuffer[LINE_BUFFER_SIZE];
size_t lineLength = 0;
bool lineOverflow = false;

bool parseNumber(char *text, float &result) {
  while (isspace(static_cast<unsigned char>(*text))) {
    ++text;
  }

  if (*text == '\0') {
    return false;
  }

  char *end = nullptr;
  result = strtof(text, &end);

  if (end == text || !isfinite(result)) {
    return false;
  }

  while (isspace(static_cast<unsigned char>(*end))) {
    ++end;
  }

  return *end == '\0';
}

void sendError(const char *reason) {
  if (activeClient && activeClient.connected()) {
    activeClient.print("ERROR=");
    activeClient.println(reason);
  }
}

void processLine(char *line) {
  char *comma = strchr(line, ',');

  if (comma == nullptr || strchr(comma + 1, ',') != nullptr) {
    sendError("expected value,threshold");
    return;
  }

  *comma = '\0';

  float value = 0.0f;
  float threshold = 0.0f;

  if (!parseNumber(line, value) || !parseNumber(comma + 1, threshold)) {
    sendError("invalid number");
    return;
  }

  const bool thresholdCrossed = value >= threshold;

  // Threshold crossed: RED on, WHITE off.
  // Normal condition: WHITE on, RED off.
  digitalWrite(RED_LED_PIN, thresholdCrossed ? HIGH : LOW);
  digitalWrite(WHITE_LED_PIN, thresholdCrossed ? LOW : HIGH);

  const char *displayLedName = thresholdCrossed ? "RED" : "WHITE";

  if (activeClient && activeClient.connected()) {
    activeClient.print("VALUE=");
    activeClient.print(value, 4);
    activeClient.print(",THRESHOLD=");
    activeClient.print(threshold, 4);
    activeClient.print(",LED_ON=");
    activeClient.println(displayLedName);
  }

  Serial.printf("VALUE=%.4f,THRESHOLD=%.4f,LED_ON=%s\n",
                value, threshold, displayLedName);
}

void setup() {
  pinMode(RED_LED_PIN, OUTPUT);
  pinMode(WHITE_LED_PIN, OUTPUT);

  digitalWrite(RED_LED_PIN, LOW);
  digitalWrite(WHITE_LED_PIN, LOW);

  Serial.begin(115200);

  WiFi.mode(WIFI_AP);
  WiFi.setSleep(false);

  if (!WiFi.softAP(AP_SSID, AP_PASSWORD)) {
    Serial.println("ERROR=WiFi access point failed to start");
  } else {
    Serial.print("WiFi network: ");
    Serial.println(AP_SSID);
    Serial.print("Dashboard target: ");
    Serial.print(WiFi.softAPIP());
    Serial.print(":");
    Serial.println(TCP_PORT);
  }

  server.begin();
  server.setNoDelay(true);
}

void loop() {
  if (!activeClient || !activeClient.connected()) {
    WiFiClient incoming = server.available();

    if (incoming) {
      activeClient = incoming;
      activeClient.setNoDelay(true);
      activeClient.println("READY: send value,threshold followed by newline");
      lineLength = 0;
      lineOverflow = false;
      Serial.println("Dashboard client connected");
    }
  }

  while (activeClient && activeClient.connected() &&
         activeClient.available() > 0) {
    const char incoming = static_cast<char>(activeClient.read());

    if (incoming == '\n') {
      if (lineOverflow) {
        sendError("line too long");
      } else {
        if (lineLength > 0 && lineBuffer[lineLength - 1] == '\r') {
          lineBuffer[lineLength - 1] = '\0';
        } else {
          lineBuffer[lineLength] = '\0';
        }

        processLine(lineBuffer);
      }

      lineLength = 0;
      lineOverflow = false;
    } else if (!lineOverflow) {
      if (lineLength < LINE_BUFFER_SIZE - 1) {
        lineBuffer[lineLength++] = incoming;
      } else {
        lineOverflow = true;
      }
    }
  }
}